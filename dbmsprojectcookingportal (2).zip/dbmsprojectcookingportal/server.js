// Import required modules
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

// Create an Express app
const app = express();

// Enable CORS
app.use(cors());

// Middleware for handling POST data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// MySQL database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',           // Your MySQL username
  password: 'swati@81105o', // Your MySQL password
  database: 'RecipePortal'  // The database you created
});

// Connect to MySQL
db.connect(err => {
  if (err) {
    console.error('Error connecting to MySQL:', err.message);
    return;
  }
  console.log('Connected to MySQL database - RecipePortal');
});

// ==============================
//        ROUTES
// ==============================

// GET: Fetch all recipes
app.get('/recipes', (req, res) => {
  const query = `SELECT * FROM recipes`;
  
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching recipes:', err.message);
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// POST: Add a new recipe
app.post('/add-recipe', (req, res) => {
  const { recipe_name, ingredients, making_time, instructions } = req.body;

  const query = `
    INSERT INTO recipes (recipe_name, ingredients, making_time, instructions) 
    VALUES (?, ?, ?, ?)
  `;

  db.query(query, [recipe_name, ingredients, making_time, instructions], (err, result) => {
    if (err) {
      console.error('Error adding recipe:', err.message);
      return res.status(500).json({ error: err.message });
    }
    console.log('Recipe added successfully!');
    res.json({ message: 'Recipe added successfully!', recipeId: result.insertId });
  });
});

// PUT: Update a recipe
app.put('/recipes/:id', (req, res) => {
  const { id } = req.params;
  const { recipe_name, ingredients, making_time, instructions } = req.body;

  const query = `
    UPDATE recipes 
    SET recipe_name = ?, ingredients = ?, making_time = ?, instructions = ? 
    WHERE id = ?
  `;

  db.query(query, [recipe_name, ingredients, making_time, instructions, id], (err, result) => {
    if (err) {
      console.error('Error updating recipe:', err.message);
      return res.status(500).json({ error: err.message });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Recipe not found' });
    }

    console.log('Recipe updated successfully!');
    res.json({ message: 'Recipe updated successfully!' });
  });
});

// DELETE: Delete a recipe
app.delete('/recipes/:id', (req, res) => {
  const { id } = req.params;

  const query = `DELETE FROM recipes WHERE id = ?`;

  db.query(query, [id], (err, result) => {
    if (err) {
      console.error('Error deleting recipe:', err.message);
      return res.status(500).json({ error: err.message });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Recipe not found' });
    }

    console.log('Recipe deleted successfully!');
    res.json({ message: 'Recipe deleted successfully!' });
  });
});

// ==============================
//        START SERVER
// ==============================

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
